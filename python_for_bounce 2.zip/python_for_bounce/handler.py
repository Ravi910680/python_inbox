import json
import pymysql
import eml_parser
from datetime import datetime
import email
import bs4
import pybase64
import re
import bs4
import sys
import os


rds_host  = "database-1.c2rgj64hihag.us-east-2.rds.amazonaws.com"
name = "admin"
password = "Ravi91068"
db_name = "auftera-crm"

conn = pymysql.connect(host=rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)


rds_host="database-1.ckv23lvefwmm.us-east-2.rds.amazonaws.com"
name="admin"
password="Ravi91068"
db_name="list_contacts"

#list_conn = pymysql.connect(host=rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)




def json_serial(obj):
  if isinstance(obj, datetime.datetime):
      serial = obj.isoformat()
      return serial




def get_body_part_of_email(raw_email):
    b=email.message_from_string(raw_email.decode())


    body = ""
    ep = eml_parser.EmlParser()



    for part in b.walk():


        ctype = part.get_content_type()
        cdispo = str(part.get('Content-Disposition'))




        body = part.get_payload(decode=True)




    return body

def get_body_of_ret_email(raw_email,key):

    ret_body=""
    for part in raw_email['body']:
        if key in part['content_header']:
            ret_body+=part['content_header'][key][0]
    return ret_body

def check_best_flg_for_status(arr):
    min_val=0;
    name_of_fnd="";
    for val in arr:
        if(min_val<arr[val]):
            min_val=arr[val]
            name_of_fnd=val;

    if(min_val==0):
        name_of_fnd="not_exist"
    print(name_of_fnd)
    if(name_of_fnd=="not_exist"):
        return 4;
    elif(name_of_fnd=="tm_out"):
        return 3;
    elif(name_of_fnd=="spam"):
        return 2;


def get_type_of_bounce(body):
    flg_spam=1;
    print(body)
    result_of_good={"not_exist":0,"spam":0,"tm_out":0}

    array_for_hard_bounce={"not_exist":["501","540","550","551","552","553","554"],"spam":["421","422","450","451","452"],"tm_out":["connection","connect","postfix" ,"timed", "out","lost","connection","handshake","EHLO"]}
    for tp in array_for_hard_bounce:
        for find_check in array_for_hard_bounce[tp]:
            if(body.find(find_check)>0):

                result_of_good[tp]+=1
    return (check_best_flg_for_status(result_of_good))








def final_list_name_from_low_name(dir_name):

    dict_for_name={"0_10k_big":"0_10K_big","10_20k_big":"10_20K_big","20k_30k_big":"20K_30K_big","30k_40k_big":"30K_40K_big","40k_big":"40K_Big"}
    return dict_for_name[dir_name]

def getCampDetFromUrl(to_email_arch,tp_sub_stat):
    print(tp_sub_stat)


    split_arr=to_email_arch[0].split('@')[0].split("-");
    create_list_name=split_arr[0]+"^"+pybase64.b64encode(str.encode(split_arr[1])).decode();
    print(create_list_name)
    con_id=split_arr[2]




#    list_conn_curs = list_conn.cursor()


#    update_query="update `"+create_list_name+"` set `substatus`='"+str(tp_sub_stat)+"' where con_id='"+con_id+"'"
#    print(update_query)
    #print(update_query)
#    list_conn_curs.execute(update_query)
#    list_conn.commit()






def lambda_handler():
    #data_file=file_name;


    # Get the object from the event and show its content type




    f = open("../test/test.eml", "rb");
    email_body=f.read();





    ep = eml_parser.EmlParser()
    parsed_eml = ep.decode_email_bytes(email_body)









    to=parsed_eml['header']['to'][0]
    email_from=parsed_eml['header']['from']
    #print(parsed_eml['header']['in-reply-to'][0]);






    if(email_from.split("@")[0]=="mailer-daemon" or email_from.split("@")[0]=="complaints"):
        print("ravi")


        find_type_of_bounce=get_type_of_bounce(get_body_of_ret_email(parsed_eml,'diagnostic-code'));

        print(find_type_of_bounce)














    else:

        subject_line=parsed_eml['header']['subject'];
        to_email=to;
        from_email=email_from;
        utc_now_dt = datetime.now().strftime("%Y-%m-%d %H:%M:%S");
        file_name="uhf344bhdhd.eml";


        print("from email :"+ from_email);
        print("to email :"+ to);
        print("subject line :"+ subject_line);
        print("UTC time now :"+ utc_now_dt);

        crm_conn = conn.cursor();
        insert_query_crm="insert into `recieve_email` (to,file_name,from,subject,date,in-reply,open,status) values ('"+to+"','"+file_name+"','"+from_email+"','"+subject_line+"','"+utc_now_dt+"','','0','0')"
        crm_conn.execute(sql, val)

        crm_conn.commit()


















file_name=sys.argv[1];
lambda_handler();
